# Jai module for sim86

* See `example.jai` for how to use this module. Compile with `jai example.jai`, as usual.
* Run `generate.jai` to recompile the library for any platform and/or rebuild the bindings from the C++ header.
